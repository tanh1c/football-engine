class SayMessage:
    pass